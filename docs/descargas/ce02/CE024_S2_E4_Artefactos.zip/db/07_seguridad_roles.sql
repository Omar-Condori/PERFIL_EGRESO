-- 07_seguridad_roles.sql -- Roles y usuarios a nivel de motor PostgreSQL (minimo privilegio)
-- Las contrasenas son de ejemplo: cambiarlas antes de usar en produccion.
-- Idempotente: crea los roles solo si no existen (los roles son del cluster y pueden estar
-- referenciados por politicas RLS de otras bases, p. ej. una copia restaurada).
DO $$
DECLARE r RECORD;
BEGIN
  FOR r IN SELECT * FROM (VALUES
      ('rol_app',NULL,NULL),('rol_lectura',NULL,NULL),('rol_auditor',NULL,NULL)) v(n,a,b) LOOP
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = r.n) THEN EXECUTE format('CREATE ROLE %I', r.n); END IF;
  END LOOP;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='app_finanzas') THEN
    CREATE ROLE app_finanzas LOGIN PASSWORD 'CambiarEnProduccion_1' CONNECTION LIMIT 20 IN ROLE rol_app; END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='analista_bi') THEN
    CREATE ROLE analista_bi LOGIN PASSWORD 'CambiarEnProduccion_2' CONNECTION LIMIT 5 IN ROLE rol_lectura; END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='auditor_ext') THEN
    CREATE ROLE auditor_ext LOGIN PASSWORD 'CambiarEnProduccion_3' CONNECTION LIMIT 2 IN ROLE rol_auditor; END IF;
END $$;

REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT USAGE ON SCHEMA public TO rol_app, rol_lectura, rol_auditor;

-- Aplicacion: DML completo sobre tablas, sin DDL ni TRUNCATE
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO rol_app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO rol_app;
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA public TO rol_app;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO rol_app;

-- Lectura: solo SELECT y sin acceso a credenciales ni sesiones
GRANT SELECT ON ALL TABLES IN SCHEMA public TO rol_lectura;
REVOKE ALL ON sessions, intrusion_attempts FROM rol_lectura;
REVOKE SELECT (passwd) ON datos_personales FROM rol_lectura;
GRANT SELECT (id, nombre, apepat, apemat, login, email, active, sucursal_actual_id) ON datos_personales TO rol_lectura;
REVOKE SELECT ON datos_personales FROM rol_lectura;
GRANT SELECT (id, nombre, apepat, apemat, login, email, active, sucursal_actual_id) ON datos_personales TO rol_lectura;

-- Auditor: solo auditoria, sesiones e intentos de intrusion
GRANT SELECT ON lab_auditoria, sessions, intrusion_attempts TO rol_auditor;
GRANT SELECT (id, user_id, status, login_time, last_activity, ip_address, is_suspicious) ON sessions TO rol_auditor;
REVOKE SELECT ON sessions FROM rol_auditor;
GRANT SELECT (id, user_id, status, login_time, last_activity, ip_address, is_suspicious) ON sessions TO rol_auditor;

-- La auditoria es de solo-anexar para la aplicacion: sin UPDATE ni DELETE
REVOKE UPDATE, DELETE ON lab_auditoria FROM rol_app;

-- Row Level Security: el cajero solo ve ventas de su sucursal (variable de sesion app.sucursal_id)
ALTER TABLE venta_registro ENABLE ROW LEVEL SECURITY;
CREATE POLICY pol_venta_sucursal ON venta_registro FOR SELECT TO rol_lectura
  USING (id_sucursal = NULLIF(current_setting('app.sucursal_id', true), '')::bigint);
CREATE POLICY pol_venta_app ON venta_registro FOR ALL TO rol_app USING (true) WITH CHECK (true);
