-- 03_integridad_indices.sql
-- Endurecimiento de integridad: FK logicas que el ORM mapea como Long, CHECK, UNIQUE e indices.
-- Se agregan como mejora del Entregable 2 (el backend las respeta en su logica).
BEGIN;
-- Claves foraneas logicas
ALTER TABLE venta_registro ADD CONSTRAINT fk_venta_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal(id_sucursal);
ALTER TABLE caja_chica     ADD CONSTRAINT fk_caja_chica_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal(id_sucursal);
ALTER TABLE productos      ADD CONSTRAINT fk_prod_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal(id_sucursal);
ALTER TABLE productos      ADD CONSTRAINT fk_prod_catalogo FOREIGN KEY (id_catalogo) REFERENCES catalogo(id);
ALTER TABLE kardex         ADD CONSTRAINT fk_kardex_catalogo FOREIGN KEY (id_catalogo) REFERENCES catalogo(id);
ALTER TABLE kardex         ADD CONSTRAINT fk_kardex_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal(id_sucursal);
ALTER TABLE compras        ADD CONSTRAINT fk_compras_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal(id_sucursal);
ALTER TABLE sessions       ADD CONSTRAINT fk_sessions_usuario FOREIGN KEY (user_id) REFERENCES datos_personales(id);
-- Restricciones CHECK (reglas de negocio)
ALTER TABLE venta_registro ADD CONSTRAINT ck_venta_total_pos CHECK (total IS NULL OR total >= 0);
ALTER TABLE venta_registro ADD CONSTRAINT ck_venta_descuento_pos CHECK (descuento IS NULL OR descuento >= 0);
ALTER TABLE venta_detalle  ADD CONSTRAINT ck_vdet_cantidad CHECK (cantidad IS NULL OR cantidad > 0);
ALTER TABLE caja_chica_movimiento ADD CONSTRAINT ck_ccm_tipo  CHECK (tipo IN ('INGRESO','EGRESO'));
ALTER TABLE caja_chica_movimiento ADD CONSTRAINT ck_ccm_monto CHECK (monto > 0);
ALTER TABLE kardex ADD CONSTRAINT ck_kardex_signo CHECK (signo IN ('+','-'));
ALTER TABLE autorizacion_descuento ADD CONSTRAINT ck_ad_estado CHECK (estado IN ('PENDIENTE','APROBADA','RECHAZADA','USADO'));
ALTER TABLE autorizacion_descuento ADD CONSTRAINT ck_ad_montos CHECK (monto_descuento >= 0 AND monto_final = monto_original - monto_descuento);
-- Unicidad
-- roles.name y permissions.name ya son UNIQUE por @Column(unique=true) en las entidades (roles_name_key, permissions_name_key)
CREATE UNIQUE INDEX uq_persona_documento ON datos_personales (tipodoc, numdoc) WHERE numdoc IS NOT NULL;
CREATE UNIQUE INDEX uq_venta_comprobante ON venta_registro (id_sucursal, tipo_doc, serie, numdoc) WHERE estado IS DISTINCT FROM 10;
-- Indices de rendimiento
CREATE INDEX idx_venta_fecha        ON venta_registro (fecha);
CREATE INDEX idx_venta_sucursal_fec ON venta_registro (id_sucursal, fecha);
CREATE INDEX idx_vdet_venta         ON venta_detalle (id_venta);
CREATE INDEX idx_ccm_caja_fecha     ON caja_chica_movimiento (id_caja_chica, fecha);
CREATE INDEX idx_kardex_cat_fecha   ON kardex (id_catalogo, id_sucursal, fecha);
CREATE INDEX idx_audit_ts           ON lab_auditoria ("timestamp");
CREATE INDEX idx_audit_user         ON lab_auditoria (user_id);
CREATE INDEX idx_sessions_user      ON sessions (user_id, status);
COMMIT;
