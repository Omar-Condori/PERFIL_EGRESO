-- 09_pruebas_bd.sql -- Suite automatizada de pruebas de base de datos (reglas de negocio e integridad)
-- Se ejecuta en una transaccion que termina en ROLLBACK: no deja datos. Uso: psql -d laboratorio_db_demo -f 09_pruebas_bd.sql
\set ON_ERROR_STOP off
\pset format aligned
\pset footer off
BEGIN;
CREATE TEMP TABLE resultados (id serial, codigo text, descripcion text, resultado text, detalle text);
GRANT ALL ON resultados TO PUBLIC; GRANT USAGE ON SEQUENCE resultados_id_seq TO PUBLIC;

-- Afirma que una sentencia FALLA (con el mensaje esperado)
CREATE FUNCTION pg_temp.espera_error(p_cod text, p_desc text, p_sql text, p_patron text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN
  BEGIN
    EXECUTE p_sql;
    INSERT INTO resultados(codigo,descripcion,resultado,detalle) VALUES (p_cod,p_desc,'FALLA','La sentencia no fue rechazada');
  EXCEPTION WHEN OTHERS THEN
    IF SQLERRM ILIKE '%'||p_patron||'%' THEN
      INSERT INTO resultados(codigo,descripcion,resultado,detalle) VALUES (p_cod,p_desc,'PASA','Rechazada: '||left(SQLERRM,70));
    ELSE
      INSERT INTO resultados(codigo,descripcion,resultado,detalle) VALUES (p_cod,p_desc,'FALLA','Error distinto: '||left(SQLERRM,70));
    END IF;
  END;
END $$;
-- Afirma que una condicion es verdadera
CREATE FUNCTION pg_temp.espera(p_cod text, p_desc text, p_cond boolean, p_det text DEFAULT '') RETURNS void LANGUAGE sql AS $$
  INSERT INTO resultados(codigo,descripcion,resultado,detalle) VALUES (p_cod,p_desc,CASE WHEN p_cond THEN 'PASA' ELSE 'FALLA' END,p_det);
$$;

\o /dev/null
-- ===== Integridad
SELECT pg_temp.espera_error('INT-01','FK: venta con sucursal inexistente',
  $q$INSERT INTO venta_registro(id_sucursal,fecha,tipo_doc,serie,numdoc,total,estado) VALUES (999,current_date,'BOLETA','B9','1',10,1)$q$,'fk_venta_sucursal');
SELECT pg_temp.espera_error('INT-02','CHECK: total negativo',
  $q$INSERT INTO venta_registro(id_sucursal,fecha,tipo_doc,serie,numdoc,total,estado) VALUES (1,current_date,'BOLETA','B9','2',-1,1)$q$,'ck_venta_total_pos');
SELECT pg_temp.espera_error('INT-03','UNIQUE: comprobante duplicado',
  $q$INSERT INTO venta_registro(id_sucursal,fecha,tipo_doc,serie,numdoc,total,estado) VALUES (2,current_date,'BOLETA','B001','00000001',10,1)$q$,'uq_venta_comprobante');
SELECT pg_temp.espera_error('INT-04','CHECK: cantidad cero en detalle',
  $q$INSERT INTO venta_detalle(id_venta,cantidad) VALUES (1,0)$q$,'ck_vdet_cantidad');
SELECT pg_temp.espera_error('INT-05','CHECK: tipo de movimiento de caja invalido',
  $q$INSERT INTO caja_chica_movimiento(tipo,monto,fecha,usuario,id_caja_chica,id_metodo_pago) VALUES ('X',5,now(),'t',1,1)$q$,'ck_ccm_tipo');
SELECT pg_temp.espera_error('INT-06','FK: no se borra una sucursal con usuarios',
  $q$DELETE FROM sucursal WHERE id_sucursal=1$q$,'foreign key');
SELECT pg_temp.espera_error('INT-07','UNIQUE: rol duplicado (roles_name_key)',
  $q$INSERT INTO roles(name,active,created_at,id_acceso) VALUES ('ROLE_ADMIN',true,now(),1)$q$,'unique constraint');

-- ===== Flujo de caja
SELECT pg_temp.espera_error('CAJ-01','Trigger: egreso mayor al saldo',
  $q$INSERT INTO caja_chica_movimiento(tipo,monto,fecha,usuario,id_caja_chica,id_metodo_pago) VALUES ('EGRESO',99999999,now(),'t',1,1)$q$,'Saldo insuficiente');
DO $$ DECLARE a numeric; b numeric; BEGIN
  SELECT saldo_actual INTO a FROM caja_chica WHERE id=1;
  INSERT INTO caja_chica_movimiento(tipo,monto,fecha,usuario,id_caja_chica,id_metodo_pago) VALUES ('INGRESO',100,now(),'t',1,1);
  SELECT saldo_actual INTO b FROM caja_chica WHERE id=1;
  PERFORM pg_temp.espera('CAJ-02','Trigger: ingreso suma al saldo', b = a + 100, 'antes='||a||' despues='||b);
  INSERT INTO caja_chica_movimiento(tipo,monto,fecha,usuario,id_caja_chica,id_metodo_pago) VALUES ('EGRESO',40,now(),'t',1,1);
  SELECT saldo_actual INTO a FROM caja_chica WHERE id=1;
  PERFORM pg_temp.espera('CAJ-03','Trigger: egreso resta del saldo', a = b - 40, 'esperado='||(b-40)||' real='||a);
  PERFORM pg_temp.espera('CAJ-04','Conciliacion: saldo registrado = saldo teorico', (SELECT saldo_actual FROM caja_chica WHERE id=1) = fn_saldo_teorico_caja(1));
END $$;
CALL sp_cerrar_caja(2, fn_saldo_teorico_caja(2), 'prueba');
SELECT pg_temp.espera('CAJ-05','Cierre de caja con arqueo exacto audita SUCCESS',
  (SELECT status FROM lab_auditoria WHERE action='CIERRE_CAJA' ORDER BY id DESC LIMIT 1)='SUCCESS');
SELECT pg_temp.espera_error('CAJ-06','Caja cerrada no admite movimientos',
  $q$INSERT INTO caja_chica_movimiento(tipo,monto,fecha,usuario,id_caja_chica,id_metodo_pago) VALUES ('INGRESO',5,now(),'t',2,1)$q$,'caja cerrada');
SELECT pg_temp.espera_error('CAJ-07','No se cierra dos veces la misma caja',
  $q$CALL sp_cerrar_caja(2, 0, 'prueba')$q$,'ya esta cerrada');

-- ===== Ventas y anulacion
SELECT pg_temp.espera_error('VEN-01','Anulacion exige motivo',
  $q$CALL sp_anular_venta(20,'x','prueba')$q$,'Motivo');
CALL sp_anular_venta(20,'Error de digitacion en la prueba','prueba');
SELECT pg_temp.espera('VEN-02','Anular deja la cabecera en estado 10', (SELECT estado FROM venta_registro WHERE id_venta=20)=10);
SELECT pg_temp.espera('VEN-03','Anular propaga el estado al detalle', (SELECT bool_and(estado=10) FROM venta_detalle WHERE id_venta=20));
SELECT pg_temp.espera('VEN-04','Anular registra la auditoria', EXISTS (SELECT 1 FROM lab_auditoria WHERE action='ANULAR_VENTA' AND details LIKE 'Venta 20 %'));
SELECT pg_temp.espera_error('VEN-05','Venta anulada es inmutable',
  $q$UPDATE venta_registro SET total=1 WHERE id_venta=20$q$,'anulada');
SELECT pg_temp.espera_error('VEN-06','No se anula una venta ya anulada',
  $q$CALL sp_anular_venta(20,'Segundo intento de anulacion','prueba')$q$,'ya esta anulada');
SELECT pg_temp.espera('VEN-07','fn_total_ventas excluye anuladas',
  fn_total_ventas(1,'2026-01-01','2026-12-31') = (SELECT sum(total) FROM venta_registro WHERE id_sucursal=1 AND estado IS DISTINCT FROM 10));
DO $$ DECLARE v bigint; BEGIN
  INSERT INTO venta_registro(id_sucursal,fecha,tipo_doc,serie,numdoc,total,estado) VALUES (1,current_date,'BOLETA','T001','1',10,1) RETURNING id_venta INTO v;
  PERFORM pg_temp.espera('VEN-08','Auditoria automatica registra la insercion de una venta',
    EXISTS (SELECT 1 FROM lab_auditoria WHERE action='INSERT' AND details='Venta '||v));
END $$;

-- ===== Seguridad
SET LOCAL ROLE analista_bi;
SELECT pg_temp.espera_error('SEG-01','Lectura: no puede leer contrasenas',$q$SELECT passwd FROM datos_personales$q$,'permission denied');
SELECT pg_temp.espera_error('SEG-02','Lectura: no puede escribir',$q$INSERT INTO sucursal(nombre,estado) VALUES ('X',1)$q$,'permission denied');
SELECT pg_temp.espera_error('SEG-03','Lectura: no accede a sesiones',$q$SELECT token FROM sessions$q$,'permission denied');
SELECT pg_temp.espera('SEG-04','RLS: sin sucursal declarada ve 0 ventas', (SELECT count(*) FROM venta_registro)=0);
SET LOCAL app.sucursal_id = '1';
SELECT pg_temp.espera('SEG-05','RLS: con sucursal 1 solo ve ventas de la sucursal 1', (SELECT count(*)>0 AND bool_and(id_sucursal=1) FROM venta_registro));
RESET ROLE;
SET LOCAL ROLE app_finanzas;
SELECT pg_temp.espera_error('SEG-06','Aplicacion: no puede borrar la auditoria',$q$DELETE FROM lab_auditoria$q$,'permission denied');
SELECT pg_temp.espera_error('SEG-07','Aplicacion: no puede crear tablas (DDL)',$q$CREATE TABLE hack(x int)$q$,'permission denied');
RESET ROLE;
SET LOCAL ROLE auditor_ext;
SELECT pg_temp.espera_error('SEG-08','Auditor: no ve ventas',$q$SELECT 1 FROM venta_registro LIMIT 1$q$,'permission denied');
RESET ROLE;

\o
\echo
\echo '=== REPORTE DE PRUEBAS DE BASE DE DATOS ==='
SELECT codigo, descripcion, resultado FROM resultados ORDER BY id;
SELECT count(*) AS total, count(*) FILTER (WHERE resultado='PASA') AS pasan, count(*) FILTER (WHERE resultado='FALLA') AS fallan FROM resultados;
ROLLBACK;
