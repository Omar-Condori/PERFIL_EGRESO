#!/usr/bin/env bash
# Prueba de restauracion: restaura un respaldo en una base temporal y compara conteos con la original.
set -euo pipefail
ARCH="$1"; ORIG="${2:-laboratorio_db}"; TMP="${ORIG}_restore_check"
dropdb --if-exists "$TMP"; createdb "$TMP"
pg_restore --no-owner --no-privileges -d "$TMP" "$ARCH" 2>/dev/null || true
for t in venta_registro venta_detalle caja_chica_movimiento lab_auditoria; do
  a=$(psql -Atd "$ORIG" -c "select count(*) from $t"); b=$(psql -Atd "$TMP" -c "select count(*) from $t")
  [ "$a" = "$b" ] && echo "OK    $t $a = $b" || { echo "DIFF  $t original=$a restaurada=$b"; exit 1; }
done
dropdb "$TMP"; echo "RESTAURACION_VERIFICADA"
