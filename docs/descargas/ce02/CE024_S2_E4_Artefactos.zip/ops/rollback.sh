#!/usr/bin/env bash
# Reversion manual: ./ops/rollback.sh <sha-anterior>   (la base se restaura aparte con pg_restore si hubo cambio de esquema)
set -euo pipefail
export BACKEND_TAG="${1:?indique el sha anterior}"
docker compose up -d backend && echo "$BACKEND_TAG" > .version_actual && echo ROLLBACK_OK "$BACKEND_TAG"
