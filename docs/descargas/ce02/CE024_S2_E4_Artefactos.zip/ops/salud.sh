#!/usr/bin/env bash
# Sonda de salud para cron/UptimeRobot. Sale con 1 y escribe en syslog si algo falla.
URL="${1:-https://api.example.org/actuator/health}"
R=$(curl -fsS -m 10 "$URL" 2>&1) && echo "$R" | grep -q '"status":"UP"' && exit 0
logger -t finanzas-salud "FALLA $URL: $R"; exit 1
