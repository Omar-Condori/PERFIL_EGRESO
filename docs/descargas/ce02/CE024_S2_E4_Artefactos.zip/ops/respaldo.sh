#!/usr/bin/env bash
# Respaldo logico diario de PostgreSQL con retencion. Cron: 0 2 * * * /opt/finanzas/ops/respaldo.sh
set -euo pipefail
DEST="${DEST:-/var/backups/finanzas}"; RETENCION_DIAS="${RETENCION_DIAS:-14}"
DB="${DB:-laboratorio_db}"; STAMP=$(date +%Y%m%d_%H%M%S); mkdir -p "$DEST"
ARCH="$DEST/${DB}_${STAMP}.dump"
if [ -n "${COMPOSE_DB_SERVICE:-}" ]; then
  docker compose exec -T "$COMPOSE_DB_SERVICE" pg_dump -U "${PGUSER:-finanzas}" -Fc "$DB" > "$ARCH"
else
  pg_dump -Fc "$DB" -f "$ARCH"
fi
pg_restore --list "$ARCH" > /dev/null          # verifica que el archivo es legible
sha256sum "$ARCH" > "$ARCH.sha256"
find "$DEST" -name "${DB}_*.dump*" -mtime +"$RETENCION_DIAS" -delete
echo "$(date -Is) RESPALDO_OK $ARCH $(stat -c%s "$ARCH") bytes"
