#!/usr/bin/env bash
# Despliegue con verificacion de salud y reversion automatica a la version previa.
# Uso: ./ops/desplegar.sh <sha-de-imagen>      (ejecutar dentro de deploy/)
set -euo pipefail
NUEVA="${1:?indique el sha}"; ESTADO=".version_actual"; PREVIA=$(cat "$ESTADO" 2>/dev/null || echo "")
URL="${HEALTH_URL:-http://localhost:8084/actuator/health}"
echo "$NUEVA" > .version_candidata
export BACKEND_TAG="$NUEVA"
./ops/respaldo.sh                                  # punto de retorno de datos antes de cambiar
docker compose pull backend && docker compose up -d backend
for i in $(seq 1 30); do
  if curl -fsS "$URL" | grep -q '"status":"UP"'; then echo "$NUEVA" > "$ESTADO"; echo "DESPLIEGUE_OK $NUEVA"; exit 0; fi
  sleep 5
done
echo "SALUD_FALLIDA: revirtiendo a ${PREVIA:-<ninguna>}"
if [ -n "$PREVIA" ]; then BACKEND_TAG="$PREVIA" docker compose up -d backend; fi
exit 1
