import { provideZonelessChangeDetection } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { HttpClient, provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { Router } from '@angular/router';
import { AuthInterceptor } from './auth.interceptor';
import { AuthService } from '../../features/auth/services/auth.service';

describe('AuthInterceptor', () => {
  let http: HttpClient;
  let ctl: HttpTestingController;
  let auth: { getToken: jasmine.Spy; logout: jasmine.Spy };
  let router: { navigate: jasmine.Spy };

  beforeEach(() => {
    auth = { getToken: jasmine.createSpy('getToken'), logout: jasmine.createSpy('logout') };
    router = { navigate: jasmine.createSpy('navigate') };
    TestBed.configureTestingModule({
      providers: [
        provideZonelessChangeDetection(),
        provideHttpClient(withInterceptors([AuthInterceptor])),
        provideHttpClientTesting(),
        { provide: AuthService, useValue: auth },
        { provide: Router, useValue: router }
      ]
    });
    http = TestBed.inject(HttpClient);
    ctl = TestBed.inject(HttpTestingController);
  });
  afterEach(() => ctl.verify());

  it('agrega el encabezado Bearer cuando hay token', () => {
    auth.getToken.and.returnValue('abc.def.ghi');
    http.get('/api/ventas').subscribe();
    const req = ctl.expectOne('/api/ventas');
    expect(req.request.headers.get('Authorization')).toBe('Bearer abc.def.ghi');
    req.flush({});
  });

  it('no agrega encabezado cuando no hay token', () => {
    auth.getToken.and.returnValue(null);
    http.get('/api/auth/health').subscribe();
    const req = ctl.expectOne('/api/auth/health');
    expect(req.request.headers.has('Authorization')).toBeFalse();
    req.flush({});
  });

  it('ante 401 cierra la sesión y redirige al login', () => {
    auth.getToken.and.returnValue('t');
    http.get('/api/ventas').subscribe({ error: () => {} });
    ctl.expectOne('/api/ventas').flush({}, { status: 401, statusText: 'Unauthorized' });
    expect(auth.logout).toHaveBeenCalled();
    expect(router.navigate).toHaveBeenCalledWith(['/login']);
  });

  it('un 401 en /auth/login NO cierra sesión (evita bucle)', () => {
    auth.getToken.and.returnValue(null);
    http.post('/api/auth/login', {}).subscribe({ error: () => {} });
    ctl.expectOne('/api/auth/login').flush({}, { status: 401, statusText: 'Unauthorized' });
    expect(auth.logout).not.toHaveBeenCalled();
  });

  it('ante 403 redirige a la pantalla de acceso denegado', () => {
    auth.getToken.and.returnValue('t');
    http.get('/api/ventas').subscribe({ error: () => {} });
    ctl.expectOne('/api/ventas').flush({}, { status: 403, statusText: 'Forbidden' });
    expect(router.navigate).toHaveBeenCalledWith(['/admin/error/403']);
  });

  it('propaga el error original al llamador', () => {
    auth.getToken.and.returnValue('t');
    let status = 0;
    http.get('/api/x').subscribe({ error: e => (status = e.status) });
    ctl.expectOne('/api/x').flush({}, { status: 500, statusText: 'Server Error' });
    expect(status).toBe(500);
  });
});
