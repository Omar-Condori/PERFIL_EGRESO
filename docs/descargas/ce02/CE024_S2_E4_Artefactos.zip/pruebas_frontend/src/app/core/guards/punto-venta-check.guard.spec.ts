import { provideZonelessChangeDetection, signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { PuntoVentaCheckGuard } from './punto-venta-check.guard';
import { AuthService } from '../../features/auth/services/auth.service';

describe('PuntoVentaCheckGuard', () => {
  let guard: PuntoVentaCheckGuard;
  let router: { navigate: jasmine.Spy };
  let user: ReturnType<typeof signal<any>>;
  let punto: ReturnType<typeof signal<string | null>>;
  const st = (url = '/admin/dashboard'): any => ({ url });

  beforeEach(() => {
    localStorage.clear();
    user = signal<any>(null);
    punto = signal<string | null>(null);
    router = { navigate: jasmine.createSpy('navigate') };
    TestBed.configureTestingModule({
      providers: [
        provideZonelessChangeDetection(),
        { provide: AuthService, useValue: { currentUser: user, currentPunto: punto } },
        { provide: Router, useValue: router }
      ]
    });
    guard = TestBed.inject(PuntoVentaCheckGuard);
  });
  afterEach(() => localStorage.clear());

  it('siempre permite la pantalla de cambio de sucursal (evita bucles)', () => {
    user.set({ rol: AuthService.ROLE_CAJERO });
    expect(guard.canActivate({} as any, st('/admin/cambio-sucursal'))).toBeTrue();
  });

  it('un usuario que no es cajero no necesita punto de venta', () => {
    user.set({ rol: 'ADMIN' });
    expect(guard.canActivate({} as any, st())).toBeTrue();
  });

  it('un cajero con punto seleccionado accede', () => {
    user.set({ rol: AuthService.ROLE_CAJERO });
    punto.set('Caja 1');
    expect(guard.canActivate({} as any, st())).toBeTrue();
  });

  it('un cajero sin punto es redirigido a seleccionarlo', () => {
    user.set({ rol: AuthService.ROLE_CAJERO });
    expect(guard.canActivate({} as any, st())).toBeFalse();
    expect(router.navigate).toHaveBeenCalled();
    const [path, extras] = router.navigate.calls.mostRecent().args;
    expect(path).toEqual(['/admin/cambio-sucursal']);
    expect(extras.queryParams.error).toBe('punto_requerido');
  });

  it('recupera el punto desde localStorage como respaldo', () => {
    user.set({ rol: AuthService.ROLE_CAJERO });
    localStorage.setItem('userId', '7');
    localStorage.setItem('puntoActual_7', 'Caja 2');
    expect(guard.canActivate({} as any, st())).toBeTrue();
    expect(punto()).toBe('Caja 2');
  });
});
