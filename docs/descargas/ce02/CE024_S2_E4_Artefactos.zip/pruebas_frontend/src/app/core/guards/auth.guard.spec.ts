import { provideZonelessChangeDetection, signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { BehaviorSubject, firstValueFrom, isObservable } from 'rxjs';
import { AuthGuard } from './auth.guard';
import { AuthService } from '../../features/auth/services/auth.service';
import { PermissionService2 } from '../../features/auth/services/permission2.service';

describe('AuthGuard', () => {
  let guard: AuthGuard;
  let router: { navigate: jasmine.Spy };
  let user: ReturnType<typeof signal<any>>;
  let permisos$: BehaviorSubject<Set<string>>;
  const state: any = { url: '/admin/ventas' };
  const route = (data: any = {}): any => ({ data });

  beforeEach(() => {
    user = signal<any>(null);
    permisos$ = new BehaviorSubject<Set<string>>(new Set());
    router = { navigate: jasmine.createSpy('navigate') };
    TestBed.configureTestingModule({
      providers: [
        provideZonelessChangeDetection(),
        { provide: AuthService, useValue: { currentUser: user } },
        { provide: PermissionService2, useValue: { permisos$ } },
        { provide: Router, useValue: router }
      ]
    });
    guard = TestBed.inject(AuthGuard);
  });

  it('sin sesión redirige al login conservando la URL de retorno', () => {
    const r = guard.canActivate(route(), state);
    expect(r).toBeFalse();
    expect(router.navigate).toHaveBeenCalledWith(['/login'], { queryParams: { returnUrl: '/admin/ventas' } });
  });

  it('usuario con token y ruta sin permiso requerido: acceso permitido', () => {
    user.set({ token: 't' });
    expect(guard.canActivate(route(), state)).toBeTrue();
  });

  it('usuario sin token se trata como no autenticado', () => {
    user.set({ token: '' });
    expect(guard.canActivate(route(), state)).toBeFalse();
  });

  it('permite la ruta cuando el usuario tiene el permiso requerido', async () => {
    user.set({ token: 't' });
    permisos$.next(new Set(['VENTA_CREAR']));
    const r: any = guard.canActivate(route({ permission: 'VENTA_CREAR' }), state);
    expect(isObservable(r)).toBeTrue();
    expect(await firstValueFrom(r)).toBeTrue();
  });

  it('deniega y redirige a 403 cuando falta el permiso', async () => {
    user.set({ token: 't' });
    permisos$.next(new Set(['VENTA_LEER']));
    const r: any = guard.canActivate(route({ permission: 'VENTA_ANULAR' }), state);
    expect(await firstValueFrom(r)).toBeFalse();
    expect(router.navigate).toHaveBeenCalledWith(['/admin/error/403']);
  });

  it('canActivateChild aplica la misma regla', () => {
    expect(guard.canActivateChild(route(), state)).toBeFalse();
  });
});
