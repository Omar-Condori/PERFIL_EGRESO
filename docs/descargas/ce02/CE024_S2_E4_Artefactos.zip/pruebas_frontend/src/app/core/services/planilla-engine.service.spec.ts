import { provideZonelessChangeDetection } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { PlanillaEngineService } from './planilla-engine.service';

describe('PlanillaEngineService (cálculo de planilla)', () => {
  let s: PlanillaEngineService;
  beforeEach(() => { TestBed.configureTestingModule({ providers: [provideZonelessChangeDetection()] }); s = TestBed.inject(PlanillaEngineService); });

  describe('calcularBaseAsegurable', () => {
    it('suma sueldo, horas extras, comisiones, bonificaciones, asignación y vacaciones', () => {
      const base = s.calcularBaseAsegurable({ sueldoBase: 2000, horasExtras: 100, comisiones: 50, bonificaciones: 30, asignacionFamiliar: 113, vacaciones: 7 });
      expect(base).toBe(2300);
    });
    it('trata conceptos ausentes como cero', () => {
      expect(s.calcularBaseAsegurable({ sueldoBase: 1500 })).toBe(1500);
      expect(s.calcularBaseAsegurable({})).toBe(0);
    });
  });

  describe('calcularAfpOnp', () => {
    it('ONP descuenta 13 %', () => {
      expect(s.calcularAfpOnp(2000, { sistemaPensionario: 'ONP' })).toBeCloseTo(260, 2);
    });
    it('AFP suma 10 % obligatorio + comisión + prima de seguro', () => {
      const d = s.calcularAfpOnp(2000, { sistemaPensionario: 'AFP', porcentajeComision: 1.55, porcentajeSeguro: 1.37 });
      expect(d).toBeCloseTo(2000 * (0.10 + 0.0155 + 0.0137), 2);
    });
    it('sin sistema pensionario no descuenta', () => {
      expect(s.calcularAfpOnp(2000, { sistemaPensionario: 'NINGUNO' })).toBe(0);
    });
    it('base cero o negativa no descuenta', () => {
      expect(s.calcularAfpOnp(0, { sistemaPensionario: 'ONP' })).toBe(0);
      expect(s.calcularAfpOnp(-5, { sistemaPensionario: 'AFP' })).toBe(0);
    });
  });

  describe('calcularQuintaCategoria', () => {
    it('base cero no genera retención', () => {
      expect(s.calcularQuintaCategoria(0)).toBe(0);
    });
    it('renta anual proyectada bajo 7 UIT no paga quinta categoría', () => {
      expect(s.calcularQuintaCategoria(2000)).toBe(0);
    });
    it('retención mensual con el valor de UIT configurado en el servicio (5 150)', () => {
      // 5 000 × 14 = 70 000; menos 7 UIT (36 050) = 33 950
      // 25 750 × 8 % + 8 200 × 14 % = 3 208  →  / 12 = 267,33
      expect(s.calcularQuintaCategoria(5000)).toBeCloseTo(267.33, 2);
    });
    it('la retención crece con la base mensual', () => {
      expect(s.calcularQuintaCategoria(9000)).toBeGreaterThan(s.calcularQuintaCategoria(5000));
    });
    // HALLAZGO H-07: el servicio usa UIT = 5 150 (valor de 2024). La UIT 2026 es S/ 5 500 (DS 301-2025-EF).
    // Con 5 500: 70 000 − 38 500 = 31 500 → 27 500×8 % + 4 000×14 % = 2 760 → 230,00 al mes.
    // Se deja pendiente (xit) hasta parametrizar la UIT; al corregirlo, cambiar xit por it.
    xit('usa la UIT vigente 2026 (5 500)', () => {
      expect(s.calcularQuintaCategoria(5000)).toBeCloseTo(230, 2);
    });
  });
});
