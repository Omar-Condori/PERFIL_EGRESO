import { FormControl } from '@angular/forms';
import { firstValueFrom, of, throwError } from 'rxjs';
import { uniqueIdValidator } from './unique-id.validator';

describe('uniqueIdValidator', () => {
  const run = (ctrl: FormControl, fn: any, current?: string) =>
    firstValueFrom(uniqueIdValidator(fn, current)(ctrl) as any);

  it('no valida cuando el campo está vacío', async () => {
    const fn = jasmine.createSpy('check').and.returnValue(of(true));
    expect(await run(new FormControl(''), fn)).toBeNull();
    expect(fn).not.toHaveBeenCalled();
  });

  it('en edición no valida contra el mismo ID', async () => {
    const fn = jasmine.createSpy('check').and.returnValue(of(true));
    expect(await run(new FormControl('A-1'), fn, 'A-1')).toBeNull();
    expect(fn).not.toHaveBeenCalled();
  });

  it('devuelve idDuplicado cuando el ID ya existe (espera 500 ms de debounce)', async () => {
    const fn = jasmine.createSpy('check').and.returnValue(of(true));
    expect(await run(new FormControl('A-2'), fn)).toEqual({ idDuplicado: true });
    expect(fn).toHaveBeenCalledWith('A-2');
  });

  it('devuelve null cuando el ID está libre', async () => {
    expect(await run(new FormControl('A-3'), () => of(false))).toBeNull();
  });

  it('no bloquea el formulario si la consulta falla', async () => {
    expect(await run(new FormControl('A-4'), () => throwError(() => new Error('red')))).toBeNull();
  });
});
