import { provideZonelessChangeDetection } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { DomSanitizer } from '@angular/platform-browser';
import { SafePipe } from './safe.pipe';

describe('SafePipe', () => {
  let pipe: SafePipe;
  beforeEach(() => { TestBed.configureTestingModule({ providers: [provideZonelessChangeDetection()] }); pipe = new SafePipe(TestBed.inject(DomSanitizer)); });

  it('marca la URL como segura para recursos (visor de PDF)', () => {
    const r: any = pipe.transform('blob:http://x/1', 'resourceUrl');
    expect(typeof r).toBe('object');
  });

  it('devuelve el texto sin cambios para otros tipos', () => {
    expect(pipe.transform('hola', 'otro')).toBe('hola');
  });
});
