// Configuración de Karma para ejecutar las pruebas en Chrome sin interfaz (CI).
module.exports = function (config) {
  config.set({
    basePath: '',
    frameworks: ['jasmine'],
    plugins: [
      require('karma-jasmine'),
      require('karma-chrome-launcher'),
      require('karma-jasmine-html-reporter'),
      require('karma-coverage')
    ],
    reporters: ['progress', 'coverage'],
    coverageReporter: { dir: require('path').join(__dirname, 'coverage'), subdir: '.', reporters: [{ type: 'text-summary' }, { type: 'json-summary' }, { type: 'html' }] },
    browsers: ['ChromeHeadlessCI'],
    customLaunchers: { ChromeHeadlessCI: { base: 'ChromeHeadless', flags: ['--no-sandbox', '--disable-gpu'] } },
    restartOnFileChange: false
  });
};
