# Repositorio técnico – Infraestructura Finanzas EPE (Semestre 2)
Despliegue: Render (Web Service Docker + PostgreSQL). Sin secretos en este repositorio.
- scripts/pruebas_conectividad.sh : 12 pruebas permitido/denegado contra la URL pública.
- scripts/sonda_disponibilidad.sh : sonda de /actuator/health.
- scripts/respaldo_render.sh : respaldo con verificación (usa DATABASE_URL por variable de entorno).
- scripts/respaldo.sh, restaurar_prueba.sh : ejercicio de respaldo/restauración en laboratorio.
- observabilidad/ : plan de monitoreo y alertas.
- diagramas/ : diagramas PNG y fuentes DOT de los Entregables 1 y 2.
- render/ : configuración sanitizada (nombres de variables; sin valores).
- logs/ : salidas de las ejecuciones (laboratorio).
- docs/ : informes.
Control de versiones: un commit por cambio; mensajes con prefijo feat/fix/docs/chore.
