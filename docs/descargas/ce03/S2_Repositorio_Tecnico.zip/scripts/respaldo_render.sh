#!/usr/bin/env bash
# Respaldo de la base de Render a un archivo local/externo. La URL externa se pasa por variable de entorno (NUNCA en el repositorio).
# Uso: DATABASE_URL='postgresql://usuario:clave@host/db' DEST=/ruta ./respaldo_render.sh
set -euo pipefail
: "${DATABASE_URL:?defina DATABASE_URL (Connect > External Database URL en el panel de Render)}"
DEST="${DEST:-./respaldos}"; RET="${RETENCION_DIAS:-14}"; mkdir -p "$DEST"
ARCH="$DEST/finanzas_$(date +%Y%m%d_%H%M%S).dump"
pg_dump --no-owner --no-privileges -Fc "$DATABASE_URL" -f "$ARCH"
pg_restore --list "$ARCH" >/dev/null
sha256sum "$ARCH" > "$ARCH.sha256"
find "$DEST" -name 'finanzas_*.dump*' -mtime +"$RET" -delete
echo "$(date -Is) RESPALDO_OK $ARCH $(stat -c%s "$ARCH") bytes"
