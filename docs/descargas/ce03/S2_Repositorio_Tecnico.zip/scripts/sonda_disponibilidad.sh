#!/usr/bin/env bash
# Sonda de disponibilidad. Cron cada 5 min: */5 * * * * /ruta/sonda_disponibilidad.sh
URL="${1:-https://finanzasepe.onrender.com/actuator/health}"
R=$(curl -fsS -m 70 "$URL" 2>&1) && echo "$R" | grep -q '"status":"UP"' && { echo "$(date -Is) UP" >> sonda.log; exit 0; }
echo "$(date -Is) DOWN $URL $R" | tee -a sonda.log; exit 1
