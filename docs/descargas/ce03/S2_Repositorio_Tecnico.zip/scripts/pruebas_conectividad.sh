#!/usr/bin/env bash
# Pruebas de conectividad y segmentación del despliegue Finanzas EPE (solo contra el sistema propio del equipo).
# No contiene secretos. Variables opcionales: BASE, DB_HOST (host externo de la base, desde el panel de Render).
# Uso: BASE=https://finanzasepe.onrender.com DB_HOST=<host> ./pruebas_conectividad.sh | tee resultados.csv
set -u
BASE="${BASE:-https://finanzasepe.onrender.com}"; DB_HOST="${DB_HOST:-}"
code(){ local o; o=$(curl -s -o /dev/null -m 70 -w '%{http_code}' "$@" 2>/dev/null) || o=ERR; echo "$o"; }
t(){ # id | descripcion | esperado | obtenido
  r="FALLA"; case ",$3," in *",$4,"*) r="PASA";; esac; echo "$1;$2;esperado=$3;obtenido=$4;$r"; }
echo "id;prueba;esperado;obtenido;resultado"
t PT-01 "GET / (HTTPS)" 200 "$(code "$BASE/")"
t PT-02 "GET /actuator" "200" "$(code "$BASE/actuator")"
t PT-03 "GET /actuator/health" 200 "$(code "$BASE/actuator/health")"
t PT-04 "GET /actuator/env no expuesto (cae a la SPA o 404)" "200,404,401,403" "$(code "$BASE/actuator/env")"
t PT-05 "GET /api/usuarios sin token" "401,403" "$(code "$BASE/api/usuarios")"
t PT-06 "GET /swagger-ui.html en producción" "401,403,404" "$(code "$BASE/swagger-ui.html")"
t PT-07 "GET /v3/api-docs en producción" "401,403,404" "$(code "$BASE/v3/api-docs")"
t PT-08 "POST /api/auth/login con credenciales inválidas" "401,403,400" "$(code -X POST -H 'Content-Type: application/json' -d '{"username":"noexiste","password":"x"}' "$BASE/api/auth/login")"
t PT-09 "POST /api/auth/register sin token" "401,403" "$(code -X POST -H 'Content-Type: application/json' -d '{}' "$BASE/api/auth/register")"
HOST="${BASE#https://}"
t PT-10 "HTTP 80 redirige a HTTPS" "301,302,307,308" "$(code "http://$HOST/")"
if [ -n "$DB_HOST" ]; then
  if timeout 8 bash -c "</dev/tcp/$DB_HOST/5432" 2>/dev/null; then o=ABIERTO; else o=CERRADO; fi
  t PT-11 "PostgreSQL 5432 desde Internet (IP no autorizada)" "CERRADO" "$o"
else echo "PT-11;PostgreSQL 5432 desde Internet;esperado=CERRADO;obtenido=OMITIDA (definir DB_HOST);OMITIDA"; fi
S=$(date +%s); c=$(code "$BASE/actuator/health"); E=$(date +%s)
echo "PT-12;Tiempo de respuesta de /actuator/health (arranque en frío si hubo inactividad);esperado<=60s;obtenido=$((E-S))s;$([ $((E-S)) -le 60 ] && echo PASA || echo FALLA)"
