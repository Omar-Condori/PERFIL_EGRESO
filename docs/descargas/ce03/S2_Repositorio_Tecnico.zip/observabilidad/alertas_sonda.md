# Plan de monitoreo (propuesta)
| Chequeo | Destino | Intervalo | Alerta |
|---|---|---|---|
| HTTP keyword "UP" | https://finanzasepe.onrender.com/actuator/health | 5 min | 2 fallos seguidos -> correo/Telegram |
| HTTPS (certificado) | https://finanzasepe.onrender.com | diario | < 14 días para vencer |
| Respaldo | archivo .sha256 más reciente | diario | > 26 h sin respaldo |
Nota: una sonda cada 5 min mantiene el servicio despierto y consume ~720 de las 750 horas gratuitas mensuales.
